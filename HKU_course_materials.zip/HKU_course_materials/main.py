import datetime
import os
import time
from multiprocessing import Pool
import random

import requests
from bs4 import BeautifulSoup
import PySimpleGUI as sg
import fake_useragent
from http import cookiejar
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains

# headers = {
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,'
#               'application/signed-exchange;v=b3;q=0.9',
#     'Accept-Encoding': 'gzip, deflate, br',
#     'Accept-Language': 'zh-CN,zh;q=0.9',
#     'Content-Type': 'application/json',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
#     'X-Requested-With': 'XMLHttpRequest'}

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,'
              'application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'keep-alive',
    'Content-Length': '173',
    'Content-Type': 'application/json',
    'Cookie': 'MoodleSession=o9atjkc3h9dd63jnj3jtiihu0r',
    'Host': 'moodle.hku.hk',
    'Origin': 'https://moodle.hku.hk',
    'Referer': 'https://moodle.hku.hk',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest'}

proxy = {'http': 'socks5://119.112.207.31:8080'}
s_path = "D:/HKU_courses_material"
url = 'https://moodle.hku.hk'
cookie_dict = dict()


def login_moodle(acc, pwd):

    generate_user_agent()
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    # chrome_options.add_argument(f'--proxy-server={proxy["http"]}')
    chrome_options.add_argument(f'--user-agent={headers["User-Agent"]}')
    driver = webdriver.Chrome(options=chrome_options)
    driver.get('https://moodle.hku.hk/login/index.php')
    driver.implicitly_wait(20)
    href_tags = driver.find_elements_by_xpath('//div[@class="loginpanel"]/div/a')
    login_entry = href_tags[0].get_attribute('href')

    try:
        driver.get(login_entry)
        driver.implicitly_wait(20)
        keyid = driver.find_element_by_xpath('//*[@id="round-corner-1"]/div/form/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td[2]/input[1]')
        driver.find_element_by_id('username').clear()
        driver.find_element_by_id('username').send_keys('ab934438')
        driver.find_element_by_id('password').clear()
        driver.find_element_by_id('password').send_keys('DnFdIBIgT6')
        driver.find_element_by_class_name('image').click()
        random_wait_time = random.randint(20, 60)
        time.sleep(random_wait_time)
        driver.implicitly_wait(20)
        print('login successfully!!!')
        cookies = driver.get_cookies()

        headers['Host'] = 'moodle.hku.hk'
        headers['Origin'] = 'https://moodle.hku.hk'
        headers['Referer'] = 'https://moodle.hku.hk'

        #     'Host': 'moodle.hku.hk',
        #     'Origin': 'https://moodle.hku.hk',
        #     'Referer': 'https://moodle.hku.hk',
        for cookie in cookies:
            if str(cookie['name']) == 'MoodleSession':

                cookie_dict.update(cookie)

        print(headers['Cookie'])

        main(driver.page_source)
        time.sleep(60)

        logout = driver.find_element_by_xpath('//*[@id="action-menu-0-menu"]/a[6]')
        driver.get(logout.get_attribute('href'))
        time.sleep(3)
        print('Logout successfully')
        driver.quit()
        return True

    except Exception as e:
        print(e)
        print('Your account or password is incorrect!!!')

    return False








    # params = {'keyid': '2021427232114',
    #           'service': 'https://moodle.hku.hk/login/index.php?authCAS=CAS',
    #           'username': acc,
    #           'password': pwd}
    # try:
    #     chrome_options = Options()
    #     chrome_options.add_argument('--headless')
    #     chrome_options.add_argument('--disable-gpu')
    #     chrome_options.add_argument(f'--proxy-server={proxy["http"]}')
    #     chrome_options.add_argument(f'--user-agent={headers["User-Agent"]}')
    #     driver = webdriver.Chrome(options=chrome_options)
    #     driver.get('https://www.jianshu.com/')
    #     driver.implicitly_wait(10)
    #     authors = driver.find_elements_by_xpath('//div/div/a[@class="nickname"]')
    #     for author in authors:
    #         print(author.text)
    #
    #
    #     html = requests.post('https://hkuportal.hku.hk/cas/servlet/edu.yale.its.tp.cas.servlet.Login', data=params)
    #     soup = BeautifulSoup(html.text, 'lxml')
    #     personal_page = soup.select('body > noscript > p > a')
    #     page_entry = personal_page[0].get('href')
    #     main(str(page_entry))
    #     print('login successfully!!!')
    #     return True
    # except Exception:
    #     print('Your account or password is incorrect!!!')
    #
    # return False


def main(html):# beautiful soup version

    # pool = Pool(processes=4)
    # soup = BeautifulSoup(html, 'lxml')
    # try:
    #     links = soup.select('#frontpage-course-list > div > div > div.info > h3 > a')  # all courses links here
    #     parsed_links = list()
    #     parsed_course_name = list()
    #     for link in links:
    #         href = link.get('href')
    #         name = link.text
    #         parsed_links.append(href)
    #         parsed_course_name.append(name)
    #
    #     print(headers)
    #     ziplist = list(zip(parsed_links, parsed_course_name))
    #
    #     pool.starmap(get_course_links, ziplist)
    #
    # except ConnectionError:
    #     print('Connection failure!')
    # finally:
    #     pool.close()
    #     pool.join()

    pool = Pool(processes=4)
    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, 'lxml')
    try:
        links = soup.select('#frontpage-course-list > div > div > div.info > h3 > a')  # all courses links here
        parsed_links = list()
        parsed_course_name = list()
        for link in links:
            href = link.get('href')
            name = link.text
            parsed_links.append(href)
            parsed_course_name.append(name)

        ziplist = list(zip(parsed_links, parsed_course_name))

        pool.starmap(get_course_links, ziplist)

    except ConnectionError:
        print('Connection failure!')
    finally:
        pool.close()
        pool.join()


def get_course_links(href, course_name):
    path = s_path + '/' + course_name
    try:
        os.mkdir(path)
    except:
        print('File exists!')

    print('access: ', href)
    grasp_course_page2(href, path)
    get_info(href)
    time.sleep(1)


def get_info(url):
    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, 'lxml')
    print(soup.select('#region-main > div.course-home.banner > div > h2 > span'))


def check_file_type(file_type):
    if file_type.find('/pdf') != -1 or file_type.find('.pdf') != -1:
        file_suffix = 'pdf'
    elif file_type.find('/powerpoint') != -1 or file_type.find('.ppt') != -1:
        file_suffix = 'ppt'
    elif file_type.find('/spreadsheet') != -1 or file_type.find('.xlsx') != -1:
        file_suffix = 'xlsx'
    elif file_type.find('/document') != -1 or file_type.find('.docx') != -1:
        file_suffix = 'docx'
    elif file_type.find('/archive') != -1 or file_type.find('.zip') != -1:
        file_suffix = 'zip'
    elif file_type.find('/folder') != -1:
        file_suffix = 'folder'
    elif file_type.find('/assign') != -1:
        file_suffix = 'assign'
    elif file_type.find('/cpp') != -1 or file_type.find('.cpp') != -1:
        file_suffix = 'cpp'
    elif file_type.find('/java') != -1 or file_type.find('.java') != -1:
        file_suffix = 'java'
    elif file_type.find('/tar') != -1 or file_type.find('.tar') != -1:
        file_suffix = 'tar'
    elif file_type.find('/jpeg') != -1 or file_type.find('.jpeg') != -1 or file_type.find('.jpg') != -1:
        file_suffix = 'jpg'
    elif file_type.find('/ino') != -1 or file_type.find('.ino') != -1:
        file_suffix = 'ino'
    elif file_type.find('/sql') != -1 or file_type.find('.sql') != -1:
        file_suffix = 'sql'
    elif file_type.find('/text') != -1 or file_type.find('.txt') != -1:
        file_suffix = 'txt'
    elif file_type.find('/py') != -1 or file_type.find('.py') != -1:
        file_suffix = 'py'
    elif file_type.find('/csv') != -1 or file_type.find('.csv') != -1:
        file_suffix = 'csv'
    elif file_type.find('/mp4') != -1 or file_type.find('.mp4') != -1 or file_type.find('/mpeg') != -1:
        file_suffix = 'mp4'
    elif file_type.find('/mov') != -1 or file_type.find('.mov') != -1:
        file_suffix = 'mov'
    elif file_type.find('/png') != -1 or file_type.find('.png') != -1:
        file_suffix = 'png'
    elif file_type.find('/url') != -1 or file_type.find('.url') != -1:
        file_suffix = 'url'
    elif file_type.find('/c') != -1 or file_type.find('.c') != -1:
        file_suffix = 'c'
    else:
        file_suffix = 'other'
    return file_suffix


def change_invalid_punctuation(mystr):
    newstr = mystr
    if mystr.find(':') != -1 or mystr.find('/') != -1 \
            or mystr.find('*') != -1 or mystr.find('"') != -1 or mystr.find('<') != -1 \
            or mystr.find('>') != -1 or mystr.find('|') != -1:
        newstr = newstr.replace(':', '_')
        newstr = newstr.replace('/', '_')
        newstr = newstr.replace('*', '_')
        newstr = newstr.replace('<', '_')
        newstr = newstr.replace('>', '_')
        newstr = newstr.replace('|', '_')
        newstr = newstr.replace('"', '_')
        newstr = newstr.replace(' ', '_')
        newstr = newstr.replace('?', '_')

    return newstr.strip()


def grasp_course_page(course_page_url, path):
    res = requests.get(course_page_url, headers=headers)
    soup = BeautifulSoup(res.text, 'lxml')
    # print(type(soup))
    section_number = 1  # Max=20
    while section_number < 20:
        new_path = path
        material_links = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a')
        file_names = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a > '
            f'span.instancename')
        section_names = soup.select(
            f'#section-{section_number} > div.content > h3.sectionname > span')  # use .text to extract the element
        file_types = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a > img')
        if len(section_names) == 0:
            print('no section')
            break
        else:
            print('Current section:', section_names[0].text)
            section_name_pure = change_invalid_punctuation(str(section_names[0].text))
            new_path = f'{path}/{section_name_pure}'
            try:
                os.mkdir(new_path)
            except Exception:
                print('folder existing')

        for m_name, m_link, file_type in zip(file_names, material_links, file_types):
            file_type = file_type.get('src')
            file_suffix = check_file_type(m_name.text)
            if file_suffix == 'other':
                file_suffix = check_file_type(file_type)
            print(m_name.text, m_link.get('href'), file_suffix)  # url of pdf file
            file_url = m_link.get('href')
            file_res = requests.get(file_url, headers=headers, allow_redirects=False)  # disable redirection is the key
            # Accessing the link will redirect to another link
            file_loc = file_res.headers.get('location')
            m_name_pure = change_invalid_punctuation(str(m_name.text))  # No special punctuation allows
            if file_loc is not None:  # This url has a response location
                print('')
                # print(file_loc)
                if (file_suffix != 'other'):
                    file = requests.get(file_loc, headers=headers)
                    with open(f'{new_path}/{m_name_pure}.{file_suffix}', 'wb') as source:
                        source.write(file.content)
                # time.sleep(1)
            else:  # This url is accessible
                accessible_url = file_url
                second_level_path = f'{new_path}/{m_name_pure}'

                if file_suffix == 'folder':
                    try:
                        os.mkdir(f'{second_level_path}')
                    except Exception:
                        print('Folder exist')
                    grasp_folder_page(accessible_url, second_level_path)
                elif file_suffix == 'assign':
                    try:
                        os.mkdir(f'{second_level_path}')
                    except Exception:
                        print('Folder exist')
                    grasp_assignment_page(accessible_url, second_level_path)
                else:
                    pass
                print('This is not a file')

        section_number += 1


def grasp_assignment_page(page_url, assignment_path):
    accessible_url = page_url  # 'https://moodle.hku.hk/mod/assign/view.php?id=1342833'
    accessible_res = requests.get(accessible_url, headers=headers)  # disable redirection is the key
    new_soup = BeautifulSoup(accessible_res.text, 'lxml')
    files = new_soup.select('div.fileuploadsubmission>a')

    for file in files:
        href = file.get('href')
        file_name = file.text
        file_name_pure = change_invalid_punctuation(file_name)
        if href.find('pluginfile.php') != -1:
            print('     ', file_name, href, check_file_type(file_name))
            file = requests.get(href, headers=headers)
            with open(f'{assignment_path}/{file_name_pure}.{check_file_type(file_name)}', 'wb') as source:
                source.write(file.content)
                source.close()


def grasp_folder_page(page_url, folder_path):
    accessible_url = page_url  # 'https://moodle.hku.hk/mod/assign/view.php?id=1342833'
    accessible_res = requests.get(accessible_url, headers=headers)  # disable redirection is the key
    new_soup = BeautifulSoup(accessible_res.text, 'lxml')
    files = new_soup.select('span.fp-filename-icon>a')
    # folder_name = new_soup.select('h2')

    for file in files:
        href = file.get('href')
        file_name = file.text
        file_name_pure = change_invalid_punctuation(file_name)
        if href.find('pluginfile.php') != -1:
            print('     ', file_name, href, check_file_type(file_name))
            file = requests.get(href, headers=headers)
            with open(f'{folder_path}/{file_name_pure}.{check_file_type(file_name)}', 'wb') as source:
                source.write(file.content)
                source.close()


def grasp_course_page2(course_page_url, path):

    html = requests.get(course_page_url, headers=headers)
    soup = BeautifulSoup(html.text, 'lxml')

    section_number = 1  # Max=20
    while section_number < 20:
        html_pattern = 1
        new_path = path
        material_links = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a')
        file_names = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a > '
            f'span.instancename')
        section_names = soup.select(
            f'#section-{section_number} > div.content > h3.sectionname > span')  # use .text to extract the element
        file_types = soup.select(
            f'#section-{section_number} > div.content > ul > li > div > div > div > div.activityinstance > a > img')

        # Check if the html is pattern 2
        summary = soup.select(
            f'#section-{section_number} > div.content > div.summary > div > p > a')  # use .text to extract the element
        if len(summary) != 0:
            # For html pattern 2
            material_links2 = soup.select(
                f'#section-{section_number} > div.content > div.summary >  div > p > a')
            file_names2 = material_links
            section_names2 = soup.select(
                f'#section-{section_number} > div.content > h3.sectionname > span')  # use .text to extract the element
            file_types2 = material_links
            material_links.extend(material_links2)
            file_names.extend(file_names2)
            section_names.extend(section_names2)
            file_types.extend(file_types2)

        if len(section_names) == 0:
            print("no section")
            break
        else:
            print('Current section:', section_names[0].text)
            section_name_pure = change_invalid_punctuation(str(section_names[0].text))
            new_path = f'{path}/{section_name_pure}'
            try:
                os.mkdir(new_path)
            except FileExistsError:
                print('folder existing')

        for m_name, m_link, file_type in zip(file_names, material_links, file_types):
            file_type = file_type.get('src')
            file_suffix = check_file_type(m_name.text)
            file_url = m_link.get('href')

            if file_type is None:
                print('Go to pattern 2 parser')
                print(m_name.text, file_suffix, file_url)
                m_name_pure = change_invalid_punctuation(m_name.text)
                if file_suffix != 'other':
                    file = requests.get(file_url, headers=headers)
                    print(new_path)
                    with open(f'{new_path}/{m_name_pure}.{file_suffix}', 'wb') as source:
                        source.write(file.content)
                        source.close()
            else:
                if file_suffix == 'other':
                    file_suffix = check_file_type(file_type)
                print(m_name.text, file_suffix, file_url)
                html_pattern = 1
                file_res = requests.get(file_url, headers=headers,
                                        allow_redirects=False)  # disable redirection is the key
                # Accessing the link will redirect to another link
                file_loc = file_res.headers.get('location')
                m_name_pure = change_invalid_punctuation(str(m_name.text))  # No special punctuation allows
                if file_loc is not None:  # This url has a response location
                    print(file_suffix)
                    if file_suffix != 'other':  # To avoid the
                        try:
                            file = requests.get(file_loc, headers=headers)
                            with open(f'{new_path}/{m_name_pure}.{file_suffix}', 'wb') as source:
                                source.write(file.content)
                                source.close()
                        except:
                            print('The link is inaccessible')

                    # time.sleep(1)
                else:  # This url is accessible
                    accessible_url = file_url
                    second_level_path = f'{new_path}/{m_name_pure}'

                    if file_suffix == 'folder':
                        try:
                            os.mkdir(f'{second_level_path}')
                        except FileExistsError:
                            print('Folder exist')
                        grasp_folder_page(accessible_url, second_level_path)
                    elif file_suffix == 'assign':
                        try:
                            os.mkdir(f'{second_level_path}')
                        except FileExistsError:
                            print('Folder exist')
                        grasp_assignment_page(accessible_url, second_level_path)
                    else:
                        pass
                    print('This is not a file')

        section_number += 1


def parse_html_pattern2_test(course_page_url, section_number):
    res = requests.get(course_page_url, headers=headers)
    soup = BeautifulSoup(res.text, 'lxml')

    material_links = soup.select(
        f'#section-{section_number} > div.content > div.summary >  div > p > a')
    file_names = material_links
    section_names = soup.select(
        f'#section-{section_number} > div.content > h3.sectionname > span')  # use .text to extract the element
    file_types = material_links
    if len(section_names) == 0:
        'no section'
    else:
        print('Current section:', section_names[0].text)
    for m_name, m_link, file_type in zip(file_names, material_links, file_types):
        file_type = file_type.text
        file_suffix = check_file_type(file_type)
        file_url = m_link.get('href')

        print(m_name.text, m_link.get('href'), file_suffix)  # url of pdf file

        m_name_pure = change_invalid_punctuation(m_name.text)
        # Accessing the link will redirect to another link
        file = requests.get(file_url, headers=headers)
        with open(f'{s_path}/{m_name_pure}.{file_suffix}', 'wb') as source:
            source.write(file.content)


def simple_gui():
    sg.theme('TealMono')

    login_win = make_login_win()
    download_win = None
    folder_path_sel_win = None


    event_listener_enable = True
    download_done = False
    while True:
        if event_listener_enable:
            window, event, values = sg.read_all_windows()
        if window == login_win:
            if event in (sg.WIN_CLOSED, 'Exit'):
                login_win.close()
                break
            # Finish up by removing from the screen
            if event == 'Login':
                ret = False
                print('Account: ', values['Acc'], ' , Password:', values['Pwd'])
                ret = login_moodle(values['Acc'], values['Acc'])
                if ret:
                    sg.popup('Login successfully !!!')
                    login_win.close()
                    login_win = None
                    folder_path_sel_win = make_folder_path_sel_win()
                else:
                    sg.popup('Your account or password is incorrect !!!')

        if window == folder_path_sel_win:
            if event == 'Submit':
                global s_path
                s_path = values['Browse']
                folder_path_sel_win.close()
                folder_path_sel_win = None
                download_win = make_download_win()
                event_listener_enable = False
                window = download_win

            if event in (sg.WIN_CLOSED, 'Exit'):
                folder_path_sel_win.close()
                break



        if window == download_win:
            while True:
                event, value = download_win.Read(timeout=20)
                progress_bar = download_win['progressbar']

                if event == 'Exit':
                    download_win.close()
                    exit()
                    break

                if not download_done:
                    for i in range(1000):
                        event, value = download_win.Read(timeout=20)
                        if event == 'Exit':
                            download_win.close()
                            exit()
                            break
                        time.sleep(0.1)
                        progress_bar.UpdateBar(i+1)
                    download_done = True


def make_login_win():
    layout = [
        [sg.Text("Login your HKU moodle to obtain your courses' resources")],
        [sg.Text("Account: "), sg.Input(key='Acc')],
        [sg.Text("Password: "), sg.Input(key='Pwd')],
        [sg.Button('Login'), sg.Button('Exit', button_color=('white', 'red'))],
    ]

    return sg.Window('HKU Moodle Login System', layout, finalize=True)

def make_download_win():
    layout = [
        [sg.Text("Downloading ... ")],
        [[sg.ProgressBar(1000, orientation='h', size=(20, 20), key='progressbar')]],
        [sg.Button('Exit', button_color=('white', 'red'))],
    ]

    return sg.Window('Downloading Documents', layout, finalize=True)


def make_folder_path_sel_win():
    layout = [
        [sg.Text("Folder path(where to settle your resources): "),sg.FolderBrowse()],
        [sg.Submit(), sg.Button('Exit', button_color=('white', 'red'))],
    ]

    return sg.Window('Select your folder path', layout, finalize=True)


def gui_test():
    sg.theme('TealMono')

    folder_path_sel_win = make_folder_path_sel_win()
    while True:
        event, value = folder_path_sel_win.read()
        print(value, event)
        if event == sg.WIN_CLOSED:
            folder_path_sel_win.close()
            break


def browse_moodle_login_page():
    generate_user_agent()
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    # chrome_options.add_argument(f'--proxy-server={proxy["http"]}')
    chrome_options.add_argument(f'--user-agent={headers["User-Agent"]}')
    driver = webdriver.Chrome(options=chrome_options)
    driver.get('https://moodle.hku.hk/login/index.php')
    driver.implicitly_wait(20)
    href_tags = driver.find_elements_by_xpath('//div[@class="loginpanel"]/div/a')
    login_entry = href_tags[0].get_attribute('href')

    driver.get(login_entry)
    driver.implicitly_wait(20)
    keyid = driver.find_element_by_xpath('//*[@id="round-corner-1"]/div/form/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td[2]/input[1]')
    driver.find_element_by_id('username').clear()
    driver.find_element_by_id('username').send_keys('ab934438')
    driver.find_element_by_id('password').clear()
    driver.find_element_by_id('password').send_keys('DnFdIBIgT6')
    driver.find_element_by_class_name('image').click()
    time.sleep(3)
    driver.implicitly_wait(20)

    print(driver.page_source)


def generate_user_agent():
    useragent = fake_useragent.UserAgent()
    ua = useragent.random
    global headers
    headers['User-Agent'] = ua


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # account = input('Your moodle account: ')
    # password = input('Your moodle password: ')
    # login_moodle('account', '')
    # simple_gui()
    # gui_test()
    generate_user_agent()
    cookie = input('Please enter your moodle page cookies: ')
    headers['Cookie'] = cookie
    print(f'Your files will be stored in {s_path}')

    main(url)


